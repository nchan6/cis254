// Norris Chan
// norrischan@my.smccd.edu
// CIS 254 OL
// loops
// File Description
// Lab #3
// Date 9/25/16
import javax.swing.JOptionPane;
public class Loops
{
   public static void main(String[] args){
       System.out.println("programmed by norris chan");
       
       //declare variables for the total of odd and even number, and the even and odd numbers
       int oddTotal = 0;
       int evenTotal = 1;
       int oddNum = 1;
       int evenNum = 1;
       
       //tests to see if oddnum is less than 50
       while ( oddNum < 50 ){
           //tests to see of oddnum is odd
           if ( oddNum%2 != 0 ){
               oddTotal += oddNum;
               oddNum++;
            } else {
                oddNum++;
            }
        }
        //tests to see if evennum is less than 25
       while ( evenNum < 25){
           //test to see if evenNum is even
           if ( evenNum%2 == 0 ){
               evenTotal *= evenNum;
               evenNum++;
            } else {
                evenNum++;
            }
           
        }
       // i used the this test to compare the answer that i would get for the evenTotal product from the while loop 
        int test = 2*4*6*8*10*12*14*16*18*20*22*24;
        
        // prints the oddTotal and the evenTotal
        System.out.println("the sum of the odd number is " + oddTotal + "\nthe product of the even numbers is " + evenTotal + "\n evenTotal test = " + test);
        
        JOptionPane.showMessageDialog(null,"programmed by norris chan \nthe sum of the odd numbers is " + oddTotal + "\nthe product of the even numbers is " + evenTotal);
    }
}
