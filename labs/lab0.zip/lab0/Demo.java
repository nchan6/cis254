//Norris Chan
//norrischan@my.smccd.edu
//CIS 254 OL
//Demo
//compiling and running a java program
//Lab #0
//8/25/16
public class Demo
{
    public static void main(String[] args){
        System.out.println("Here is a Java program");
        System.out.println("Written by Norris Chan");
    }
}
