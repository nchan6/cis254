//Norris Chan
//norrischan@my.smccd.edu
//CIS 254 OL
//MyInfo
//Info about me
//Lab#1
//8/26/16
public class MyInfo
{
    public static void main(String[] args){
        System.out.println("My name is Norris Chan.");
        System.out.println("My major is computer science.");
    }
}
