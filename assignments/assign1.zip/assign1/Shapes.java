// Norris Chan
// norrischan@my.smccd.edu
// CIS 254 OL
// digits
// prints individual characters of a string
// Assignment #1
// 9/6/16
public class Shapes
{
    public static void main(String[] args){
        System.out.println("Program by Norris Chan");
        System.out.println("*********      ***        *         *");
        System.out.println("*       *    *     *     ***       * *");
        System.out.println("*       *   *       *   *****     *   *");
        System.out.println("*       *   *       *     *      *     *");
        System.out.println("*       *   *       *     *     *       *");
        System.out.println("*       *   *       *     *      *     *");
        System.out.println("*       *   *       *     *       *   *");
        System.out.println("*       *    *     *      *        * *");
        System.out.println("*********      ***        *         *");
    }
}
    

